import { useState, useEffect } from 'react';
import { Brain, Loader2, CheckCircle, AlertCircle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';

const ChainlinkAnalysis = ({ 
  ipfsHash, 
  onAnalysisComplete, 
  isAnalyzing, 
  analysisData, 
  analysisError,
  onStartAnalysis,
  onCheckResults,
  isConfirmed,
  addLog 
}) => {
  const [checkingResults, setCheckingResults] = useState(false);

  // Handle analysis completion
  useEffect(() => {
    if (analysisData && !isAnalyzing) {
      addLog('Análise recebida com sucesso!');
      onAnalysisComplete(analysisData);
    }
  }, [analysisData, isAnalyzing, onAnalysisComplete, addLog]);

  const handleStartAnalysis = () => {
    if (!ipfsHash) {
      alert('Faça upload de uma imagem primeiro');
      return;
    }
    
    addLog(`Iniciando análise para IPFS: ${ipfsHash}`);
    onStartAnalysis(ipfsHash);
  };

  const handleCheckResults = async () => {
    setCheckingResults(true);
    addLog('Verificando resultados manualmente...');
    
    try {
      const result = await onCheckResults();
      if (result.success) {
        addLog('Resultados encontrados!');
      } else {
        addLog(`Verificação: ${result.error}`);
      }
    } catch (error) {
      addLog(`Erro na verificação: ${error.message}`);
    }
    
    setCheckingResults(false);
  };

  const renderAnalysisResults = () => {
    if (!analysisData) return null;

    return (
      <Card className="mt-4">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-500" />
            Resultados da Análise
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <h4 className="font-semibold">Análise de Sentimentos</h4>
              <p className="text-sm text-muted-foreground">
                {analysisData.sentiment_analysis || 'Não disponível'}
              </p>
            </div>
            
            <div className="space-y-2">
              <h4 className="font-semibold">Psicologia das Cores</h4>
              <p className="text-sm text-muted-foreground">
                {analysisData.color_psychology || 'Não disponível'}
              </p>
            </div>
            
            <div className="space-y-2">
              <h4 className="font-semibold">Linguagem Visual</h4>
              <p className="text-sm text-muted-foreground">
                {analysisData.visual_language || 'Não disponível'}
              </p>
            </div>
            
            <div className="space-y-2">
              <h4 className="font-semibold">Relação Simbólica</h4>
              <p className="text-sm text-muted-foreground">
                {analysisData.symbol_relation || 'Não disponível'}
              </p>
            </div>
            
            {analysisData.keywords && (
              <div className="space-y-2 md:col-span-2">
                <h4 className="font-semibold">Palavras-chave</h4>
                <div className="flex flex-wrap gap-2">
                  {analysisData.keywords.map((keyword, index) => (
                    <Badge key={index} variant="secondary">
                      {keyword}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
            
            {analysisData.attributes && (
              <div className="space-y-2 md:col-span-2">
                <h4 className="font-semibold">Atributos NFT</h4>
                <div className="flex flex-wrap gap-2">
                  {analysisData.attributes.map((attr, index) => (
                    <Badge key={index} variant="outline">
                      {attr.trait_type}: {attr.value}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            Análise de Sentimentos via Chainlink Functions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                onClick={handleStartAnalysis}
                disabled={!ipfsHash || isAnalyzing}
                size="lg"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Analisando...
                  </>
                ) : (
                  <>
                    <Brain className="mr-2 h-4 w-4" />
                    Iniciar Análise
                  </>
                )}
              </Button>

              {isConfirmed && !analysisData && (
                <Button 
                  onClick={handleCheckResults}
                  disabled={checkingResults}
                  variant="outline"
                  size="lg"
                >
                  {checkingResults ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Verificando...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4" />
                      Verificar Resultados
                    </>
                  )}
                </Button>
              )}
            </div>

            {isAnalyzing && (
              <Alert>
                <Loader2 className="h-4 w-4 animate-spin" />
                <AlertDescription>
                  Executando análise via Chainlink Functions... 
                  {isConfirmed ? ' Transação confirmada! Use "Verificar Resultados" para buscar a resposta.' : ' Aguardando confirmação da transação...'}
                </AlertDescription>
              </Alert>
            )}

            {analysisError && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Erro na análise: {analysisError.message}
                </AlertDescription>
              </Alert>
            )}
          </div>
        </CardContent>
      </Card>

      {renderAnalysisResults()}
    </div>
  );
};

export default ChainlinkAnalysis;

