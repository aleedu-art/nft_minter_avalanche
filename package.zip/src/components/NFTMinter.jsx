import { useState } from 'react';
import { Coins, Loader2, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useWriteContract, useWaitForTransactionReceipt } from 'wagmi';
import { CONTRACTS, NFT_ABI } from '../lib/web3';

const NFTMinter = ({ metadata, analysisData, ipfsHash, addLog }) => {
  const [isMinting, setIsMinting] = useState(false);
  const [tokenId, setTokenId] = useState(null);
  const [metadataUri, setMetadataUri] = useState('');

  const { writeContract, data: hash, error: writeError } = useWriteContract();
  const { isLoading: isConfirming, isSuccess: isConfirmed } = useWaitForTransactionReceipt({
    hash,
  });

  const uploadMetadataToIPFS = async (metadata) => {
    addLog('Fazendo upload dos metadados para IPFS...');
    
    try {
      const response = await fetch('https://nft-fuji-minter.onrender.com/upload-json', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(metadata)
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      addLog(`Metadados enviados para IPFS: ${data.IpfsHash}`);
      return data.IpfsHash;
    } catch (error) {
      addLog(`Erro no upload de metadados: ${error.message}`);
      throw error;
    }
  };

  const mintNFT = async () => {
    if (!metadata || !analysisData || !ipfsHash) {
      alert('Dados de análise e metadados necessários');
      return;
    }

    try {
      setIsMinting(true);
      addLog('Iniciando processo de mint NFT...');

      // Upload metadata to IPFS first
      const metadataHash = await uploadMetadataToIPFS(metadata);
      const metadataURI = `https://gateway.pinata.cloud/ipfs/${metadataHash}`;
      setMetadataUri(metadataURI);

      addLog('Chamando contrato NFT para mint...');

      // Prepare data for minting
      const keywords = analysisData.keywords || [];
      
      await writeContract({
        address: CONTRACTS.NFT_CONTRACT,
        abi: NFT_ABI,
        functionName: 'mintWithSentiment',
        args: [
          '0x3AEeb98795F2Af057E59E67313A1cc7331d549e7', // to address - replace with actual user
          metadataURI,
          ipfsHash,
          analysisData.sentiment_analysis || '',
          analysisData.color_psychology || '',
          analysisData.symbol_relation || '',
          analysisData.visual_language || '',
          keywords
        ],
      });

      addLog(`Transação de mint enviada: ${hash}`);
      
    } catch (error) {
      addLog(`Erro no mint: ${error.message}`);
      setIsMinting(false);
    }
  };

  // Handle successful mint
  if (isConfirmed && isMinting) {
    addLog('NFT mintado com sucesso!');
    setIsMinting(false);
    // You could extract token ID from transaction receipt here
  }

  return (
    <Card className="mt-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Coins className="h-5 w-5" />
          Mint NFT com Análise de Sentimentos
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="text-center">
            <Button 
              onClick={mintNFT}
              disabled={!metadata || !analysisData || isMinting || isConfirming}
              size="lg"
              className="w-full md:w-auto"
            >
              {isMinting || isConfirming ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {isConfirming ? 'Confirmando...' : 'Mintando...'}
                </>
              ) : (
                <>
                  <Coins className="mr-2 h-4 w-4" />
                  Mint NFT
                </>
              )}
            </Button>
          </div>

          {writeError && (
            <Alert variant="destructive">
              <AlertDescription>
                Erro no mint: {writeError.message}
              </AlertDescription>
            </Alert>
          )}

          {hash && (
            <Alert>
              <AlertDescription className="flex items-center gap-2">
                Transação enviada: 
                <a 
                  href={`https://testnet.snowtrace.io/tx/${hash}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-500 hover:underline flex items-center gap-1"
                >
                  {hash.slice(0, 10)}...{hash.slice(-8)}
                  <ExternalLink className="h-3 w-3" />
                </a>
              </AlertDescription>
            </Alert>
          )}

          {isConfirmed && (
            <Alert className="border-green-500 bg-green-50 dark:bg-green-950">
              <AlertDescription>
                🎉 NFT mintado com sucesso! Token criado na blockchain.
              </AlertDescription>
            </Alert>
          )}

          {metadataUri && (
            <Alert>
              <AlertDescription className="flex items-center gap-2">
                Metadados IPFS: 
                <a 
                  href={metadataUri}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-500 hover:underline flex items-center gap-1"
                >
                  Ver metadados
                  <ExternalLink className="h-3 w-3" />
                </a>
              </AlertDescription>
            </Alert>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default NFTMinter;

