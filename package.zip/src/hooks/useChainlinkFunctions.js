import { useState, useCallback } from 'react';
import { useWriteContract, useReadContract, useWaitForTransactionReceipt } from 'wagmi';
import { CONTRACTS, CHAINLINK_ABI, GAS_CONFIG } from '../lib/web3';

export const useChainlinkFunctions = () => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisData, setAnalysisData] = useState(null);
  const [analysisError, setAnalysisError] = useState(null);

  const { writeContract, data: hash, error: writeError } = useWriteContract();
  
  const { isLoading: isConfirming, isSuccess: isConfirmed } = useWaitForTransactionReceipt({
    hash,
  });

  // Read functions
  const { data: lastResponse, refetch: refetchResponse } = useReadContract({
    address: CONTRACTS.CHAINLINK_FUNCTIONS,
    abi: CHAINLINK_ABI,
    functionName: 's_lastResponse',
  });

  const { data: lastError, refetch: refetchError } = useReadContract({
    address: CONTRACTS.CHAINLINK_FUNCTIONS,
    abi: CHAINLINK_ABI,
    functionName: 's_lastError',
  });

  const { data: lastRequestId, refetch: refetchRequestId } = useReadContract({
    address: CONTRACTS.CHAINLINK_FUNCTIONS,
    abi: CHAINLINK_ABI,
    functionName: 's_lastRequestId',
  });

  const sendAnalysisRequest = useCallback(async (ipfsHash) => {
    try {
      setIsAnalyzing(true);
      setAnalysisError(null);
      setAnalysisData(null);
      
      console.log(`🚀 Enviando request para análise: ${ipfsHash}`);
      console.log('⚙️ Configuração de gas:', GAS_CONFIG);
      console.log('📍 Contrato:', CONTRACTS.CHAINLINK_FUNCTIONS);
      console.log('🔑 Subscription ID:', CONTRACTS.SUBSCRIPTION_ID);
      
      // Parâmetros para Chainlink Functions
      const secretsLocation = 1; // DONHosted
     // const encryptedSecretsReference = "0x"; // Empty for DON hosted secrets
      //const encryptedSecretsReference = "0x0000000000685d715b";
      const encryptedSecretsReference = "0x0000000000685e83ae";
      const args = [ipfsHash];
      const bytesArgs = [];
      const callbackGasLimit = 300000;
     
     
    // const sourceCode = "return Functions.encodeString(JSON.stringify({ message: 'Hello World!' }));";

 
const sourceCode = `
const imageHash = args[0];

if (!secrets.openaiKey) {
  throw Error("Need to set OPENAI_KEY environment variable");
}

const prompt = \`Analyze the sentiment and visual characteristics of an NFT image with IPFS hash: \${imageHash}.
Provide a detailed analysis in the following JSON format:
{
  "sentiment_analysis": "detailed emotional analysis of the image",
  "color_psychology": "analysis of colors and their psychological impact",
  "symbol_relation": "symbolic meaning and cultural references",
  "visual_language": "description of visual elements and composition",
  "keywords": ["keyword1", "keyword2", "keyword3"],
  "attributes": [
    {"trait_type": "Emotion", "value": "Joy"},
    {"trait_type": "Style", "value": "Abstract"}
  ]
}
Respond only with valid JSON.\`;

const openAIRequest = Functions.makeHttpRequest({
  url: "https://api.openai.com/v1/chat/completions",
  method: "POST",
  headers: {
    "Authorization": \`Bearer \${secrets.openaiKey}\`,
    "Content-Type": "application/json"
  },
  data: {
    model: "gpt-3.5-turbo",
    messages: [
      {
        role: "system",
        content: "You are an expert NFT and art analyst. Analyze images and provide detailed sentiment analysis in JSON format."
      },
      {
        role: "user",
        content: prompt
      }
    ],
    max_tokens: 1000,
    temperature: 0.7
  }
});

const [openAiResponse] = await Promise.all([openAIRequest]);

console.log(JSON.stringify(openAiResponse, null, 2));

if (
  !openAiResponse ||
  !openAiResponse.data ||
  !openAiResponse.data.choices ||
  !openAiResponse.data.choices[0]
) {
  throw Error("Resposta inválida da OpenAI API");
}

const result = openAiResponse.data.choices[0].message.content;

return Functions.encodeString(result);
`;
 


      console.log('📋 Parâmetros da transação:', {
        source: sourceCode,
        secretsLocation,
        encryptedSecretsReference,
        args,
        bytesArgs,
        subscriptionId: CONTRACTS.SUBSCRIPTION_ID,
        callbackGasLimit,
        gasConfig: GAS_CONFIG
      });

      console.log('🚨 IMPORTANTE: Source deve estar vazio:', sourceCode === "" ? "✅ CORRETO" : "❌ ERRO - Source não está vazio!");

 

      const result = await writeContract({
        address: CONTRACTS.CHAINLINK_FUNCTIONS,
        abi: CHAINLINK_ABI,
        functionName: 'sendRequest',
        args: [
          sourceCode, // EXPLICITAMENTE vazio
          secretsLocation,
          encryptedSecretsReference,
          args,
          bytesArgs,
          CONTRACTS.SUBSCRIPTION_ID,
          callbackGasLimit
        ],



        ...GAS_CONFIG, // Usar configuração de gas otimizada
      });

      console.log('✅ Transação enviada com sucesso:', result);

    } catch (error) {
      console.error('❌ Erro detalhado ao enviar request:', {
        message: error.message,
        code: error.code,
        data: error.data,
        stack: error.stack
      });
      
      // Tratamento específico de erros
      let userFriendlyError = error.message;
      
      if (error.message.includes('insufficient funds')) {
        userFriendlyError = 'Saldo insuficiente de AVAX para gas';
      } else if (error.message.includes('gas')) {
        userFriendlyError = 'Problema com configuração de gas';
      } else if (error.message.includes('revert')) {
        userFriendlyError = 'Transação rejeitada pelo contrato';
      } else if (error.message.includes('network')) {
        userFriendlyError = 'Problema de conexão com a rede';
      }
      
      setAnalysisError(new Error(userFriendlyError));
      setIsAnalyzing(false);
    }
  }, [writeContract]);

  // Manual check for results
  const checkResults = useCallback(async () => {
    try {
      console.log('Verificando resultados manualmente...');
      
      // Refetch the latest data
      await refetchResponse();
      await refetchError();
      await refetchRequestId();

      // Check if we have a response
      if (lastResponse && lastResponse !== '0x' && lastResponse.length > 2) {
        try {
          // Convert hex to string
          const responseString = lastResponse.slice(2); // Remove 0x
          const bytes = [];
          for (let i = 0; i < responseString.length; i += 2) {
            bytes.push(parseInt(responseString.substr(i, 2), 16));
          }
          const decodedString = new TextDecoder().decode(new Uint8Array(bytes));
          
          console.log('Resposta encontrada:', decodedString);
          
          // Try to parse as JSON
          const parsedData = JSON.parse(decodedString);
          setAnalysisData(parsedData);
          setIsAnalyzing(false);
          
          return { success: true, data: parsedData };
        } catch (parseError) {
          console.error('Erro ao parsear resposta:', parseError);
          return { success: false, error: 'Resposta ainda não está pronta ou é inválida' };
        }
      }

      // Check for errors
      if (lastError && lastError !== '0x' && lastError.length > 2) {
        const errorString = lastError.slice(2);
        const bytes = [];
        for (let i = 0; i < errorString.length; i += 2) {
          bytes.push(parseInt(errorString.substr(i, 2), 16));
        }
        const decodedError = new TextDecoder().decode(new Uint8Array(bytes));
        
        const error = new Error(`Chainlink Error: ${decodedError}`);
        setAnalysisError(error);
        setIsAnalyzing(false);
        
        return { success: false, error: decodedError };
      }

      // No response yet
      return { success: false, error: 'Ainda aguardando resposta...' };

    } catch (error) {
      console.error('Erro ao verificar resultados:', error);
      return { success: false, error: error.message };
    }
  }, [lastResponse, lastError, refetchResponse, refetchError, refetchRequestId]);

  return {
    sendAnalysisRequest,
    checkResults,
    isAnalyzing,
    isConfirming,
    isConfirmed,
    analysisData,
    analysisError,
    writeError,
    hash,
    lastResponse,
    lastError,
    lastRequestId
  };
};

